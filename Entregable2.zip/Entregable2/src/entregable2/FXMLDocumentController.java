/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entregable2;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Validator;
import jgpx.model.analysis.TrackData;
import jgpx.model.gpx.Track;
import jgpx.model.jaxb.GpxType;
import jgpx.model.jaxb.TrackPointExtensionT;
import jgpx.util.DateTimeUtils;

/**
 *
 * @author erfersi
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private TextArea text;

    @FXML
    private Button loadButton;
    private TrackData trackData;

    final FileChooser fileChooser = new FileChooser();
    @FXML
    private Button graf;
    @FXML
   // private PieChart queso;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        /*PieChart queso = new PieChart();
    ObservableList<PieChart.Data> pieChartData
            = FXCollections.observableArrayList(
                    new PieChart.Data("Grapefruit", 13),
                    new PieChart.Data("Oranges", 25),
                    new PieChart.Data("Plums", 10),
                    new PieChart.Data("Pears", 22),
                    new PieChart.Data("Apples", 30));

    queso.setData (pieChartData);

    queso.setTitle ("Imported Fruits");*/
        
    }

    @FXML
    private void load(ActionEvent event) throws JAXBException {

        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(loadButton.getScene().getWindow());
        label.setText("Cargando datos... " + file.getName());
        if (file == null) {
            return;
        }

        JAXBContext jaxbContext = JAXBContext.newInstance(GpxType.class, TrackPointExtensionT.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<Object> root = (JAXBElement<Object>) unmarshaller.unmarshal(file);
        GpxType gpx = (GpxType) root.getValue();

        //TrackData trackData = new TrackData(new Track(gpx.getTrk().get(0)));
        if (gpx != null) {
            trackData = new TrackData(new Track(gpx.getTrk().get(0)));
            showTrackInfo(trackData);
            label.setText("Archivo de datos GPX cargado correctamente");
        } else {
            label.setText("Error cargando el archivo GPX desde " + file.getName());
        }
    }

    private void showTrackInfo(TrackData trackData) {
        text.setText("\na. Fecha y hora de inicio: " + DateTimeUtils.format(trackData.getStartTime()));
        text.appendText("\nb. Duración: " + DateTimeUtils.format(trackData.getTotalDuration()));//en horas minutos y segundos
        text.appendText("\nc. Tiempo en movimiento: " + DateTimeUtils.format(trackData.getMovingTime()));
        text.appendText(String.format("\nd. Distancia total recorrida: %.0f Kilómetros", +trackData.getTotalDistance()));//corregiir a KM
        text.appendText(String.format("\ne.1. Desnivel acumulado de subida: %.2f metros", trackData.getTotalAscent()));
        text.appendText(String.format("\ne.2. Desnivel acumulado de bajada: %.2f metros", trackData.getTotalDescend()));
        text.appendText(String.format("\nf.1. Velocidad máxima: %.0f Km/h", trackData.getMaxSpeed()));
        text.appendText(String.format("\nf.2. Velocidad media: %.2f Km/h", trackData.getAverageSpeed()));
        text.appendText(String.format("\ng.1. Frecuencia Cardiaca (FC) máxima: %d ppm", trackData.getMaxHeartrate()));
        text.appendText(String.format("\ng.2. Frecuencia Cardiaca (FC) mínima: %d ppm", trackData.getMinHeartRate()));
        text.appendText(String.format("\ng.3. Frecuencia Cardiaca (FC) media: %d ppm", trackData.getAverageHeartrate()));
        text.appendText(String.format("\nh.1. Cadencia de pedaleo máxima: %d pedaleadas por minuto", trackData.getMaxCadence()));
        text.appendText(String.format("\nh.1. Cadencia de pedaleo media: %d pedaleadas por minuto", trackData.getAverageCadence()));
    }

    
}
